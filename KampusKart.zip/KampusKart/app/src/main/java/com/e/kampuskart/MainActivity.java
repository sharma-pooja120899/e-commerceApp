package com.e.kampuskart;

import android.content.Intent;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ImageView logo;
    TextView Title,slogan;
    Animation scaleanim,translateanim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        logo=findViewById(R.id.logo);
        Title=findViewById(R.id.title);
        slogan=findViewById(R.id.slogan);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        scaleanim= AnimationUtils.loadAnimation(this,R.anim.large);
        translateanim=AnimationUtils.loadAnimation(this,R.anim.translate);
        logo.startAnimation(scaleanim);
        Title.startAnimation(scaleanim);
        slogan.startAnimation(translateanim);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(MainActivity.this,Login.class));
                finish();

            }
        },3500);

    }
}
